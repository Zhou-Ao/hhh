# -*- coding: utf-8 -*-
"""
Created on Tue Jan 10 14:11:17 2017

@author: strategy.intern.2
"""
from createDoc2016 import createDoc2016

#urls = ['https://www.federalreserve.gov/fomc/MINUTES/1993/19930203min.htm',
#        'https://www.federalreserve.gov/fomc/MINUTES/1993/19930323min.htm']
        
urls = ["https://www.federalreserve.gov/monetarypolicy/fomcminutes20160127.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20160316.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20160427.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20160615.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20160727.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20160921.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20161102.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20161214.htm"]

myStopWords = ["monday", "tuesday", "wednesday", "thursday", "firday", "saturday", "sunday",
                    "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december",
                    "year", "quarter", "month", "day",
                    "first", "second", "third", "fourth",
                    "federal", "reserve", "session", "percent",
                    "recent", "fomc", "cre",
                    "committe", "member"]

docs = []    
for url in urls:
    docs.append(createDocAllPara(url, myStopWords))                    

from gensim import corpora, models
# create document term matrix
dictionary = corpora.Dictionary(docs)
corpus = [dictionary.doc2bow(text) for text in docs]

ldamodel = models.ldamodel.LdaModel(corpus, num_topics=20, id2word = dictionary, passes=100)
print(ldamodel.print_topics(num_topics=8, num_words=5))

#i = 0;
#for doc in docs:
#    i += 1
#    with open('doc'+str(i)+'.txt', 'a') as f:
#        for words in doc:
#            f.write(words)
#            f.write(' ')