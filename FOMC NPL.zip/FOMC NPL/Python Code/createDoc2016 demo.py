# -*- coding: utf-8 -*-
"""
Created on Tue Jan 10 15:31:10 2017

@author: strategy.intern.2
"""
# read html
import requests

url = 'https://www.federalreserve.gov/monetarypolicy/fomcminutes20160127.htm'
page = requests.get(url)

# load Beautiful Soap
from bs4 import BeautifulSoup

soup = BeautifulSoup(page.content, 'html.parser')

div_content = soup.find(id='content')
strong_tag_list = div_content.find_all('strong')

text = ''
for strong_tag in strong_tag_list:
#    print(strong_tag.contents[0])
    if ('Open Market Operations' not in strong_tag.contents[0]) \
        and ('Secretary' not in strong_tag.contents[0]) \
        and ('Voting' not in strong_tag.contents[0]) \
        and ('Vote' not in strong_tag.contents[0]):
            for sibling in strong_tag.parent.next_siblings:
#                print(sibling)
                if(sibling.name == 'p' and sibling.string != None):
                    text += sibling.string
                elif(sibling.name == 'strong'):
                    break


for child in div_content.find_all('p'):
    print(child.string)
    if(child.name == 'p' and child.string != None):
        text += child.string