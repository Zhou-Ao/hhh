# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# read html
import requests

url = 'https://www.federalreserve.gov/monetarypolicy/fomcminutes20160127.htm'
page = requests.get(url)

# load Beautiful Soap
from bs4 import BeautifulSoup

soup = BeautifulSoup(page.content, 'html.parser')

div_content = soup.find(id='content')

text = ''
hr = div_content.find_all('hr')[2]
for sibling in hr.next_siblings:
#    print(sibling.string)
    if(sibling.name == 'p' and sibling.string != None):
        text += sibling.string
    elif(sibling.name == 'hr'):
        break
    
text = ''
for child in div_content.find_all('p'):
    print(child.string)
    if(child.name == 'p' and child.string != None):
        text += child.string
    
# tokenize text
from nltk.tokenize import RegexpTokenizer
tokenizer = RegexpTokenizer(r'\w+')
raw = text.lower()
tokens = tokenizer.tokenize(raw)

# stop words
from stop_words import get_stop_words

# create English stop words list
en_stop = get_stop_words('en')
# user defined stop words
myStopWords = ["monday", "tuesday", "wednesday", "thursday", "firday", "saturday", "sunday",
                "january", "februay", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december",
                "year", "quarter", "month", "day",
                "first", "second", "third", "fourth",
                "federal", "reserve", "session", "percent",
                "recent", "fomc", "cre"]
                
en_stop += myStopWords

# remove stop words from tokens
stopped_tokens = [i for i in tokens if not i in en_stop]

# stemming
from nltk.stem.porter import PorterStemmer
# Create p_stemmer of class PorterStemmer
p_stemmer = PorterStemmer()
# stem token
stemed_tokens = [p_stemmer.stem(i) for i in stopped_tokens]
# filter out work with length 1 and numbers
doc = [token for token in stemed_tokens if len(token)>1 and not token.isdigit()]
         