# -*- coding: utf-8 -*-
"""
Created on Tue Jan 10 14:03:00 2017

@author: strategy.intern.2
"""
import requests
from bs4 import BeautifulSoup

def createDoc2016(url, myStopWords):
    page = requests.get(url)
    
    soup = BeautifulSoup(page.content, 'html.parser')

    div_content = soup.find(id='content')
    
    strong_tag_list = div_content.find_all('strong')

    text = ''
    for strong_tag in strong_tag_list:
    #    print(strong_tag.contents[0])
        if ('Open Market Operations' not in strong_tag.contents[0]) \
            and ('Secretary' not in strong_tag.contents[0]) \
            and ('Voting' not in strong_tag.contents[0]) \
            and ('Vote' not in strong_tag.contents[0]):
                for sibling in strong_tag.parent.next_siblings:
    #                print(sibling)
                    if(sibling.name == 'p' and sibling.string != None):
                        text += sibling.string
                    elif(sibling.name == 'strong'):
                        break
        
    # tokenize text
    from nltk.tokenize import RegexpTokenizer
    tokenizer = RegexpTokenizer(r'\w+')
    raw = text.lower()
    tokens = tokenizer.tokenize(raw)
    
    # stop words
    from stop_words import get_stop_words
    
    # create English stop words list
    en_stop = get_stop_words('en')
    # add user defined stop words
    en_stop += myStopWords
    
    # remove stop words from tokens
    stopped_tokens = [i for i in tokens if not i in en_stop]
    
    # stemming
    from nltk.stem.porter import PorterStemmer
    # Create p_stemmer of class PorterStemmer
    p_stemmer = PorterStemmer()
    # stem token
    stemed_tokens = [p_stemmer.stem(i) for i in stopped_tokens]
    # filter out work with length 1 and numbers
    doc = [token for token in stemed_tokens if len(token)>1 and not token.isdigit()]
           
    return doc