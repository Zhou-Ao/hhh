# -*- coding: utf-8 -*-
"""
Created on Tue Jan 10 14:03:00 2017

@author: strategy.intern.2
"""
import requests
from bs4 import BeautifulSoup

def is_p_without_children(tag):
    return (tag.name == 'p' and len(tag.contents) == 1 and tag.string != None)

def createDocAllPara(url, myStopWords):
    page = requests.get(url)
    
    soup = BeautifulSoup(page.content, 'html.parser')

    para_contents = soup.find_all(is_p_without_children)
    
    text = [content.contents[0] for content in para_contents]
    text = ' '.join(text)
        
    # tokenize text
    from nltk.tokenize import RegexpTokenizer
    tokenizer = RegexpTokenizer(r'\w+')
    raw = text.lower()
    tokens = tokenizer.tokenize(raw)
    
    # stop words
    from stop_words import get_stop_words
    
    # create English stop words list
    en_stop = get_stop_words('en')
    # add user defined stop words
    en_stop += myStopWords
    
    # remove stop words from tokens
    stopped_tokens = [i for i in tokens if not i in en_stop]
    
    # stemming
    from nltk.stem.porter import PorterStemmer
    # Create p_stemmer of class PorterStemmer
    p_stemmer = PorterStemmer()
    # stem token
    stemed_tokens = [p_stemmer.stem(i) for i in stopped_tokens]
    # filter out work with length 1 and numbers
    doc = [token for token in stemed_tokens if len(token)>1 and not token.isdigit()]
           
    return doc