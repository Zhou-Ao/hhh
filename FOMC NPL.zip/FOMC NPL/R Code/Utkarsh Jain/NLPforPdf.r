#install.packages(c("tm", "wordcloud", "Rstem", "topicmodels", "tau"))
#install.packages(c("lda", "ggplot2", "reshape2", "plyr"))
require("lda")
require("ggplot2")
require("reshape2")
require("plyr")
library(tm)
library(wordcloud)
library(Rstem)
library(topicmodels)

main <- function(hlink){
    
    ##CARRY OUT NLP ON THE PDF's TO OBTAIN DOCUMENT-TERM-MATRIX
  
    hlink <- "https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20160727.pdf"
    dest <- tempfile(fileext = ".pdf")
    download.file(hlink, dest, mode = "wb")
  
    # set path to pdftotxt.exe and convert pdf to text
    exe <- "C:\\Program Files\\xpdfbin-win-3.04\\bin32\\pdftotext.exe"
    system(paste("\"", exe, "\" \"", dest, "\"", sep = ""), wait = F)
    
    # get txt-file name and open it
    filetxt <- sub(".pdf", ".txt", dest)
    while(!file.exists(filetxt)){
      now<-as.numeric(Sys.time()); howlong<-1; delt<-0; while(delt < howlong) { delt<-as.numeric(Sys.time())-now }
    }
    shell.exec(filetxt)#; shell.exec(filetxt) 
    while(!file.exists(filetxt)){
      now<-as.numeric(Sys.time()); howlong<-1; delt<-0; while(delt < howlong) { delt<-as.numeric(Sys.time())-now }
    }
      
    txt <- readLines(filetxt) # don't mind warning
    
    txt <- tolower(txt)
    txt <- removeWords(txt, c("\\f", stopwords()))
    txt <- removeNumbers(txt)
    txt <- removeWords(txt, length(words) > 15)
    #unlist(txt)[!(unlist(txt) %in% stopWords)]
    
    corpus <- Corpus(VectorSource(txt))
    corpus <- tm_map(corpus, removePunctuation)
    tdm <- DocumentTermMatrix(corpus, control = list(removePunctuation = TRUE, stopwords = TRUE))
    #removeSparseTerms(tdm, 0.1)
    
    # convert into lda format
    mycora <- dtm2ldaformat(tdm, omit_empty = TRUE)
    
    # m <- as.matrix(tdm)
    # d <- data.frame(freq = sort(rowSums(m), decreasing = TRUE))
    # # Stem words
    # d$stem <- wordStem(row.names(d), language = "english")
    # # and put words to column, otherwise they would be lost when aggregating
    # d$word <- row.names(d)
    # # remove web address (very long string):
    # d <- d[nchar(row.names(d)) < 20, ]
    # # aggregate frequency by word stem and
    # # keep first words..
    # agg_freq <- aggregate(freq ~ stem, data = d, sum)
    # agg_word <- aggregate(word ~ stem, data = d, function(x) x[1])
    # d <- cbind(freq = agg_freq[, 2], agg_word)
    # # sort by frequency
    # d <- d[order(d$freq, decreasing = T), ]
    # # print wordcloud:
    # #wordcloud(d$word, d$freq)

    
    ##CARRY OUT LDA ON THE DOCUMENT-TERM-MATRIX OBTAINED
    set.seed(8675309)
    
    K = 5 ## Num clusters
    result = lda.collapsed.gibbs.sampler(mycora$documents,
                                         K,  ## Num clusters
                                         newvocab,
                                         25,  ## Num iterations
                                         50/K,
                                         200/length(newvocab),
                                         compute.log.likelihood=TRUE)
    
    ## Get the top words in the cluster
    top.words <- top.topic.words(result$topics, 5, by.score=FALSE)
    
    ## Number of documents to display
    N <- 10
    
    topic.proportions <- t(result$document_sums) / colSums(result$document_sums)
    topic.proportions <- topic.proportions[sample(1:dim(topic.proportions)[1], N),]
    topic.proportions[is.na(topic.proportions)] <-  1 / K
    
    colnames(topic.proportions) <- apply(top.words, 2, paste, collapse=" ")
    
    topic.proportions.df <- melt(cbind(data.frame(topic.proportions),
                                       document=factor(1:N)),
                                 variable.name="topic",
                                 id.vars = "document")
    
    topic.proportions.df <- ddply(topic.proportions.df,.(topic),summarize,value=sum(value/10))
    
    # remove files
    #file.remove(dir(tempdir(), full.name=T))
    
    return (topic.proportions.df)
}

#plot the listforplot in seperate graphs
plotter <- function(plist){
  for (j in 1:length(plist)){
  # theme_set(theme_bw())
  # set.seed(8675309)
  # ggplot(plist[j], aes(x=topic, y=value, fill=document), ylab="proportion") +
  #   geom_bar(stat="identity") +
  #   theme(axis.text.x = element_text(angle=90, hjust=1)) +
  #   coord_flip() +
  #   facet_wrap(~ document, ncol=5)
  barplot (plist[[j]]$value, names.arg = plist[[j]]$topic, ylim = 0:1)
  }
}


# here are the pdfs for mining
urls <- c(#"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20150128.pdf"
          #,"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20150318.pdf"
          #,"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20150429.pdf"
          #,"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20150617.pdf"
          #,"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20150729.pdf"
          #,"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20150917.pdf"
          #,"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20151028.pdf"
          #,"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20151216.pdf"
          #,"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20160127.pdf"
          #,"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20160316.pdf"
          #,"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20160427.pdf"
          #,"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20160615.pdf"
          "https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20160727.pdf"
          ,"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20160921.pdf"
          ,"https://www.federalreserve.gov/monetarypolicy/files/fomcminutes20161102.pdf"
          )

#intializations
i <- 1
listforplot <- list()
newvocab <- as.vector(read.csv("//fap02/Home/strategy.intern.7/Desktop/fullvocab.csv", header = FALSE))
newvocab <- as.vector(newvocab[[1]])
#stopWords <- stopwords("en")


#calling functions
for (url in urls){
  listforplot[[i]] <- main(url)
  i <- i+1
}
plotter(listforplot)
