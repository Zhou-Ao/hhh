library(xml2)
library(tm)
library(topicmodels)

#set working directory (modify path as needed)
setwd("U:\\FOMC NPL\\R Code")


urlList <- c("https://www.federalreserve.gov/monetarypolicy/fomcminutes20160127.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20160316.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20160427.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20160615.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20160727.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20160921.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20161102.htm",
            "https://www.federalreserve.gov/monetarypolicy/fomcminutes20161214.htm")

#wordFilter <- c("[^a-zA-Z\\s]", "[\\s]+", "\\n")
#wordFilter <- c(wordFilter, "monday", "tuesday", "wednesday", "thursday", "firday", "saturday", "sunday")
#wordFilter <- c(wordFilter, "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december")
#wordFilter <- c(wordFilter, "first", "second", "third", "fourth")
#wordFilter <- c(wordFilter, "year", "month", "day")
#wordFilter <- c(wordFilter, "federal", "reserve", "session", "percent")
#wordFilter <- c(wordFilter, "recent")

filterWords <- function(words, wordFilter)
{
  temp <- removeWords(words, c("\\f", stopwords()))
  temp <- removeNumbers(temp)
  
  for (item in wordFilter)
  {
    temp <- stringr::str_replace_all(words, item, " ")
  }
  
  return(temp)
}

readReport <- function(url)
{
  myHtml <- read_html(url)
  
  para <- xml_find_all(myHtml, ".//p")
  
  text_para <- xml_text(para)
  
  text <- character()
  i=1
  
  sIndex <- -1
  eIndex <- 1
  startingSign <- "staff review of the economic situation"
  endingSign <- "voting for this action"
  
  for(line in text_para)
  {
    #print(text_para[i])
    temp <- tolower(line)
    
    if(length(grep(startingSign, temp)) > 0)
    {
      print("Start:")
      print(i)
      sIndex <- i
    }
    else if(length(grep(endingSign, temp)) > 0)
    {
      print("End: ")
      print(i)
      eIndex <- i-1
    }
    
    text[i] <- temp
    
    i <- i+1
  }
  
  return_text <- text[sIndex:eIndex-1]
  
  return(paste(return_text, collapse=" "))
  
}


reports <- lapply(urlList, readReport)

reports <- list()
dirs <- c('./doc/doc1.txt', './doc/doc2.txt', './doc/doc3.txt', './doc/doc4.txt', './doc/doc5.txt', './doc/doc6.txt', './doc/doc7.txt', './doc/doc8.txt')
for (i in 1:8)
{
  reports[i] <- readChar(dirs[i], file.info(dirs[i])$size)
}


docs <- Corpus(VectorSource(reports))

#remove potentially problematic symbols
toSpace <- content_transformer(function(x, pattern) { return (gsub(pattern, " ", x))})
docs <- tm_map(docs, toSpace, "-")
docs <- tm_map(docs, toSpace, "'")
docs <- tm_map(docs, toSpace, "'")
docs <- tm_map(docs, toSpace, ".")
docs <- tm_map(docs, toSpace, """)
docs <- tm_map(docs, toSpace, """)

#remove punctuation
docs <- tm_map(docs, removePunctuation)
#Strip digits
docs <- tm_map(docs, removeNumbers)
#remove stopwords
docs <- tm_map(docs, removeWords, stopwords("english"))
#remove whitespace
docs <- tm_map(docs, stripWhitespace)
#Good practice to check every now and then
writeLines(as.character(docs[[3]]))
#Stem document
docs <- tm_map(docs,stemDocument)

myStopwords <- c("monday", "tuesday", "wednesday", "thursday", "firday", "saturday", "sunday",
                "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december",
                "year", "quarter", "month", "day",
                "first", "second", "third", "fourth",
                "federal", "reserve", "session", "percent",
                "recent", "fomc", "cre")

docs <- tm_map(docs, removeWords, myStopwords)
#inspect a document as a check
writeLines(as.character(docs[[3]]))

#Create document-term matrix
dtm <- DocumentTermMatrix(docs, control = list(removePunctuation = TRUE, stopwords = TRUE))

#collapse matrix by summing over columns
freq <- colSums(as.matrix(dtm))
#length should be total number of terms
length(freq)
#create sort order (descending)
ord <- order(freq,decreasing=TRUE)
#List all terms in decreasing order of freq and write to disk
freq[ord]
write.csv(freq[ord],"word_freq.csv")

#mycora <- dtm2ldaformat(tdm, omit_empty = TRUE)

#Set parameters for Gibbs sampling
burnin <- 4000
iter <- 2000
thin <- 500
seed <-list(2003,5,63,100001,765)
nstart <- 5
best <- TRUE

#Number of topics
k <- 8

#Run LDA using Gibbs sampling
ldaOut <-LDA(dtm,k, method="Gibbs", control=list(nstart=nstart, seed = seed, best=best, burnin = burnin, iter = iter, thin=thin))

#write out results
#docs to topics
ldaOut.topics <- as.matrix(topics(ldaOut))
write.csv(ldaOut.topics,file=paste("LDAGibbs",k,"DocsToTopics.csv"))

#top 6 terms in each topic
ldaOut.terms <- as.matrix(terms(ldaOut,6))
write.csv(ldaOut.terms,file=paste("LDAGibbs",k,"TopicsToTerms.csv"))


#probabilities associated with each topic assignment
topicProbabilities <- as.data.frame(ldaOut@gamma)
write.csv(topicProbabilities,file=paste("LDAGibbs",k,"TopicProbabilities.csv"))


#Find relative importance of top 2 topics
topic1ToTopic2 <- lapply(1:nrow(dtm),function(x)
  sort(topicProbabilities[x,])[k]/sort(topicProbabilities[x,])[k-1])


#Find relative importance of second and third most important topics
topic2ToTopic3 <- lapply(1:nrow(dtm),function(x)
  sort(topicProbabilities[x,])[k-1]/sort(topicProbabilities[x,])[k-2])


#write to file
write.csv(topic1ToTopic2,file=paste("LDAGibbs",k,"Topic1ToTopic2.csv"))
write.csv(topic2ToTopic3,file=paste("LDAGibbs",k,"Topic2ToTopic3.csv"))