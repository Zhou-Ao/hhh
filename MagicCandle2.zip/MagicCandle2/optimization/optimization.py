# -*- coding: utf-8 -*-
"""
Created on Tue Jan 31 16:36:06 2017

@author: strategy.intern.2
"""

import datetime
import pandas as pd
import numpy as np
import tia.bbg.datamgr as dm
from candle.candle import CandleChart
from backtesting.backtest import CandleBacktester

# read input data
tickerList = ["AUDCAD BGN Curncy", "AUDCHF BGN Curncy", "AUDJPY BGN Curncy", 
              "AUDNZD BGN Curncy", "AUDUSD BGN Curncy", "CADCHF BGN Curncy",
              "CADJPY BGN Curncy", "CHFJPY BGN Curncy", "EURAUD BGN Curncy", 
              "EURCAD BGN Curncy", "EURCHF BGN Curncy", "EURGBP BGN Curncy",
              "EURJPY BGN Curncy", "EURNZD BGN Curncy", "EURUSD BGN Curncy", 
              "GBPAUD BGN Curncy", "GBPCAD BGN Curncy", "GBPCHF BGN Curncy",
              "GBPJPY BGN Curncy", "GBPNZD BGN Curncy", "GBPUSD BGN Curncy", 
              "NZDCAD BGN Curncy", "NZDCHF BGN Curncy", "NZDJPY BGN Curncy",
              "NZDUSD BGN Curncy", "USDCAD BGN Curncy", "USDCHF BGN Curncy", 
              "USDCNH BGN Curncy", "USDJPY BGN Curncy", "USDSGD BGN Curncy",
              "XAUUSD BGN Curncy", "DXY Curncy", "SPX Index", "SX5E Index",
              "UKX Index", "NKY Index", "AS51 Index", "KOSPI Index", 
              "SENSEX Index","TWSE Index", "HSCI Index", "JCI Index", 
              "SET Index", "FBMKLCI Index","NIFTY Index",
              "SHCOMP Index","XAG Curncy","XPT Curncy",
              "XPD Curncy","CL1 Comdty" ]
              
#startTime = datetime.date(2009,9,10)
#endTime = datetime.date(2017,1,31)
#endTime = datetime.date.today()
endTime = datetime.date(2017,2,6)
startTime = endTime - datetime.timedelta(900*3)

mgr = dm.BbgDataManager()
#curncy = mgr[tickerList]
#
#rawDf = curncy.get_historical(['PX_OPEN', 'PX_HIGH', 'PX_LOW', 'PX_LAST'], 
#                              startTime.strftime('%m/%d/%Y'), endTime.strftime('%m/%d/%Y'))


for ticker in tickerList:
    curncy = mgr[ticker]
    rawDf = curncy.get_historical(['PX_OPEN', 'PX_HIGH', 'PX_LOW', 'PX_LAST'], 
                              startTime.strftime('%m/%d/%Y'), endTime.strftime('%m/%d/%Y'))
    
    chart = CandleChart(ticker, 'Day', 1, rawDf.index.tolist(), 
        rawDf.PX_OPEN.tolist(), rawDf.PX_HIGH.tolist(), rawDf.PX_LOW.tolist(), rawDf.PX_LAST.tolist())
    
    # calculate candle metrics
    chart.CaculateBarMetrics()
    chart.CaculateATR()
    
#    #Engulf
#    for bar2atr in np.arange(1.1, 1.5, 0.05):
#        for body2atr in np.arange(0.6, 0.9, 0.05):
#            print(ticker + ': Engulf1 and Engulf2')
#            print((bar2atr, body2atr))
#            chart.AddEngulf1(bar2atr, body2atr)
#            chart.AddEngulf2(bar2atr, body2atr)
#            
#    #InsideBar
#    for bart22atr in np.arange(0.6, 0.9, 0.05):
#        print(ticker + ': InsideBar1')
#        print((bart22atr))
#        chart.AddInsideBar1(bart22atr)
#        for bart12atr in np.arange(0.6, 0.9, 0.05):
#            for bodyt12atr in np.arange(0.6, 0.9, 0.05):
#                print(ticker + ': InsideBar2')
#                print((bart22atr, bart12atr, bodyt12atr))
#                chart.AddInsideBar2(bart22atr, bart12atr, bodyt12atr)
    
    #Hammer
    for bar2atr in np.arange(0.6, 0.9, 0.05):
        for body2atr in np.arange(0.2, 0.4, 0.05):
            for lowershadow2body in np.arange(2.0, 5.0, 0.5):
                for uppershadow2body in np.arange(0.05, 0.2, 0.05):
                        print(ticker)
                        print((bar2atr, body2atr, lowershadow2body, uppershadow2body))
                        chart.AddHammer2(bar2atr, body2atr, lowershadow2body, uppershadow2body)
                    
    
                    
#    signalList = [signal for signal in chart.chartDf.columns if ('Engulf' in signal) or ('InsideBar' in signal)]                
    signalList = [signal for signal in chart.chartDf.columns if 'Hammer' in signal]
                  
    # backtest
    backtester0 = CandleBacktester(ticker, startTime, endTime)
    backtester1 = CandleBacktester(ticker, startTime, datetime.date(2012, 12,31))
    backtester2 = CandleBacktester(ticker, datetime.date(2013, 1, 1), datetime.date(2015, 12,31))
    backtester3 = CandleBacktester(ticker, datetime.date(2016, 1, 1), endTime)
#    holdingPeriod = 3
    for holdingPeriod in [3, 5]:
        backtester0.BacktestDaily(signalList, chart.chartDf, chart.signalPara, holdingPeriod)
        backtester1.BacktestDaily(signalList, chart.chartDf, chart.signalPara, holdingPeriod)
        backtester2.BacktestDaily(signalList, chart.chartDf, chart.signalPara, holdingPeriod)
        backtester3.BacktestDaily(signalList, chart.chartDf, chart.signalPara, holdingPeriod)