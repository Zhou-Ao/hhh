# -*- coding: utf-8 -*-
"""
Created on Wed Jan 25 15:14:44 2017

@author: Ao
"""
import numpy as np
from utility.utility import CandleUtility

class CandleShape:
    
    # Hammer 4
    # Rules (Long)
    # 1.       Bar > 0.7*ATR
    # 2.       Open <= Average (Prev 3 Opens)
    # 3.       Body < 0.38*ATR
    # 4.       Lower Shadow > 2.0*Body
    # 5.       Upper Shadow < 0.1 * Body
    # 7.       Must be White 
    @staticmethod
    def Hammer4Long(df, bar2atr, body2atr, lowershadow2body, uppershadow2body):
        if set(['BarToATR', 'Open', 'BodyToATR', 'UpperShadowToBody',
                'LowerShadowToBody', 'Close']).issubset(df.columns):
                logic1 = np.array(df.BarToATR) > bar2atr
                logic2 = np.array(df.Open) <= np.array(df.Open.rolling(window=4).apply(lambda x: np.mean(x[:-1])))
                logic3 = np.array(df.BodyToATR) > body2atr
                logic4 = np.array(df.LowerShadowToBody) > lowershadow2body
                logic5 = np.array(df.UpperShadowToBody) < uppershadow2body
                logic6 = np.array(df.Close) > np.array(df.Open) # white bar
                                 
                return logic1 & logic2 & logic3 & logic4 & logic5 & logic6
            
        else:
            raise Exception('CandleShape: Invalid dataframe!')

    # Hammer 4
    # Rules (Short)
    # 1.       Bar > 0.7*ATR
    # 2.       Open >= Average (Prev 3 Opens)
    # 3.       Body < 0.38*ATR
    # 4.       Lower Shadow > 2.0*Body
    # 5.       Upper Shadow < 0.1 * Body
    # 7.       Must be Filled 
    @staticmethod
    def Hammer4Short(df, bar2atr, body2atr, lowershadow2body, uppershadow2body):
        if set(['BarToATR', 'Open', 'BodyToATR', 'UpperShadowToBody',
                'LowerShadowToBody', 'Close']).issubset(df.columns):
                logic1 = np.array(df.BarToATR) > bar2atr
                logic2 = np.array(df.Open) >= np.array(df.Open.rolling(window=4).apply(lambda x: np.mean(x[:-1])))
                logic3 = np.array(df.BodyToATR) > body2atr
                logic4 = np.array(df.LowerShadowToBody) > lowershadow2body
                logic5 = np.array(df.UpperShadowToBody) < uppershadow2body
                logic6 = np.array(df.Close) < np.array(df.Open) # filled bar
                                 
                return logic1 & logic2 & logic3 & logic4 & logic5 & logic6
            
        else:
            raise Exception('CandleShape: Invalid dataframe!')
    
    
    
    
    
    
    
    # Hammer 1
    # Rules (Long)
    # 1.       Bar > 0.7*ATR
    # 2.       Open <= Average (Prev 3 Opens)
    # 3.       Body > 0.38*ATR
    # 4.       Lower Shadow > 0.28*ATR
    # 5.       Lower Shadow > 2* Upper Shadow
    # 6.       Upper Shadow < 0.35 * Body
    # 7.       Must be White Bar
    @staticmethod
    def Hammer1Long(df, bar2atr, body2atr, lowershadow2atr, lowershadow2uppershadow, 
                    uppdershadow2body):
        if set(['BarToATR', 'Open', 'BodyToATR', 'LowerShadowToATR',
                'LowerShadowToUpperShadow', 'UpperShadowToBody', 'Close']).issubset(df.columns):
                logic1 = np.array(df.BarToATR) > bar2atr
                logic2 = np.array(df.Open) <= np.array(df.Open.rolling(window=4).apply(lambda x: np.mean(x[:-1])))
                logic3 = np.array(df.BodyToATR) > body2atr
                logic4 = np.array(df.LowerShadowToATR) > lowershadow2atr
                logic5 = np.array(df.LowerShadowToUpperShadow) > lowershadow2uppershadow
                logic6 = np.array(df.UpperShadowToBody) < uppdershadow2body
                logic7 = np.array(df.Close) > np.array(df.Open) # white bar
                                 
                return logic1 & logic2 & logic3 & logic4 & logic5 & logic6 & logic7
            
        else:
            raise Exception('CandleShape: Invalid dataframe!')
    
    # Hammer1
    # Rules (Short)
    # 1.       Bar > 0.7*ATR
    # 2.       Open >= Average (Prev 3 Opens)
    # 3.       Body > 0.38*ATR
    # 4.       Upper Shadow > 0.28*ATR
    # 5.       Upper Shadow > 2* Lower Shadow
    # 6.       Lower Shadow < 0.35 * Body
    # 7.       Must be Filled Bar
    @staticmethod
    def Hammer1Short(df, bar2atr, body2atr, uppershadow2atr, uppershadow2lowershadow, 
                     lowershadow2body):
        if set(['BarToATR', 'Open', 'BodyToATR', 'LowerShadowToATR', 
            'LowerShadowToUpperShadow', 'UpperShadowToBody', 'Close']).issubset(df.columns):
                logic1 = np.array(df.BarToATR) > bar2atr
                logic2 = np.array(df.Open) >= np.array(df.Open.rolling(window=4).apply(lambda x: np.mean(x[:-1])))
                logic3 = np.array(df.BodyToATR) > body2atr
                logic4 = np.array(df.UpperShadowToATR) > uppershadow2atr
                logic5 = np.array(df.UpperShadowToLowerShadow) > uppershadow2lowershadow
                logic6 = np.array(df.LowerShadowToBody) < lowershadow2body
                logic7 = np.array(df.Close) < np.array(df.Open) # filled bar
                                 
                return logic1 & logic2 & logic3 & logic4 & logic5 & logic6 & logic7
            
        else:
            raise Exception('CandleShape: Invalid dataframe!')

    # Hammer 2
    # Rules (Long)
    # 1.       Bar > 0.7*ATR
    # 2.       Open <= Average (Prev 3 Opens)
    # 3.       Upper shadow < 0.44 *Lower shadow
    # 4.       Lower shadow > 0.55 *Bar
    # 5.       Lower Shadow + Body > 0.7* ATR
    # 6.       Must be White Bar
    @staticmethod   
    def Hammer2Long(df, bar2atr, uppershadow2lowershadow, lowershadow2bar,
                    lowershadowplusbody2atr):
        if set(['BarToATR', 'Open', 'UpperShadowToLowerShadow', 'LowerShadowToBar',
            'LowerShadowToATR', 'BodyToATR', 'Close']).issubset(df.columns):
                logic1 = np.array(df.BarToATR) > bar2atr
                logic2 = np.array(df.Open) <= np.array(df.Open.rolling(window=4).apply(lambda x: np.mean(x[:-1])))
                logic3 = np.array(df.UpperShadowToLowerShadow) < uppershadow2lowershadow
                logic4 = np.array(df.LowerShadowToBar) > lowershadow2bar
                logic5 = (np.array(df.LowerShadowToATR) + np.array(df.BodyToATR)) > lowershadowplusbody2atr
                logic6 = np.array(df.Close) > np.array(df.Open) # white bar
                
                return logic1 & logic2 & logic3 & logic4 & logic5 & logic6
        else:
            raise Exception('CandleShape: Invalid dataframe!')

    # Hammer2
    # Rules (Short)
    # 1.       Bar > 0.7*ATR
    # 2.       Open >= Average (Prev 3 Opens)
    # 3.       Lower shadow < 0.44 *Upper shadow
    # 4.       Upper shadow > 0.55 *Bar
    # 5.       Upper Shadow + Body > 0.7* ATR
    # 6.       Must be Filled Bar
    @staticmethod
    def Hammer2Short(df, bar2atr, lowershadow2uppershadow, uppershadow2bar,
                    uppershadowplusbody2atr):
        if set(['BarToATR', 'Open', 'LowerShadowToUpperShadow', 'UpperShadowToBar', 
            'UpperShadowToATR', 'BodyToATR', 'Close']).issubset(df.columns):
                logic1 = np.array(df.BarToATR) > bar2atr
                logic2 = np.array(df.Open) >= np.array(df.Open.rolling(window=4).apply(lambda x: np.mean(x[:-1])))
                logic3 = np.array(df.LowerShadowToUpperShadow) < lowershadow2uppershadow
                logic4 = np.array(df.UpperShadowToBar) > uppershadow2bar
                logic5 = (np.array(df.UpperShadowToATR) + np.array(df.BodyToATR)) > uppershadowplusbody2atr
                logic6 = np.array(df.Close) < np.array(df.Open) # filled bar
                
                return logic1 & logic2 & logic3 & logic4 & logic5 & logic6
        else:
            raise Exception('CandleShape: Invalid dataframe!')
    
    # Hammer 3
    # Rules (Long)
    # 1.       Bar > 0.7*ATR
    # 2.       Open <= Average (Prev 3 Opens)
    # 3.       Lower Shadow >= 0.5*ATR
    # 4.       Upper shadow < 0.15 *Bar
    # 5.       Upper shadow < 0.2* Lower
    # 6.       Lower shadow > 0.7*Bar
    @staticmethod
    def Hammer3Long(df, bar2atr, lowershadow2atr, uppershadow2bar, 
                    uppershadow2lowershadow, lowershadow2bar):
        if set(['BarToATR', 'Open', 'Close', 'LowerShadowToATR', 'UpperShadowToBar', 
            'UpperShadowToLowerShadow', 'LowerShadowToBar']).issubset(df.columns):
                logic1 = np.array(df.BarToATR) > bar2atr
                logic2 = np.array(df.Open) <= np.array(df.Open.rolling(window=4).apply(lambda x: np.mean(x[:-1])))
                logic3 = np.array(df.LowerShadowToBar) >= lowershadow2bar
                logic4 = np.array(df.UpperShadowToBar) < uppershadow2bar
                logic5 = np.array(df.UpperShadowToLowerShadow) < uppershadow2lowershadow
                logic6 = np.array(df.LowerShadowToBar) > lowershadow2bar
                
                return logic1 & logic2 & logic3 & logic4 & logic5 & logic6
        else:
            raise Exception('CandleShape: Invalid dataframe!')

    # Hammer3
    # Rules (Short)
    # 1.       Bar > 0.7*ATR
    # 2.       Open >= Average (Prev 3 Opens)
    # 3.       Upper Shadow >= 0.5*ATR
    # 4.       Lower shadow < 0.15 *Bar
    # 5.       Lower shadow < 0.2* Upper 
    # 6.       Upper shadow > 0.7*Bar
    @staticmethod
    def Hammer3Short(df, bar2atr, uppershadow2atr, lowershadow2bar, 
                    lowershadow2uppershadow, uppershadow2bar):
        if set(['BarToATR', 'Open', 'Close', 'LowerShadowToATR', 'UpperShadowToBar', 
            'UpperShadowToLowerShadow', 'LowerShadowToBar']).issubset(df.columns):
                logic1 = np.array(df.BarToATR) > bar2atr
                logic2 = np.array(df.Open) >= np.array(df.Open.rolling(window=4).apply(lambda x: np.mean(x[:-1])))
                logic3 = np.array(df.UpperShadowToBar) >= uppershadow2atr
                logic4 = np.array(df.LowerShadowToBar) < lowershadow2bar
                logic5 = np.array(df.LowerShadowToUpperShadow) < lowershadow2uppershadow
                logic6 = np.array(df.UpperShadowToBar) > uppershadow2bar
                
                return logic1 & logic2 & logic3 & logic4 & logic5 & logic6
        else:
            raise Exception('CandleShape: Invalid dataframe!')
            
    # Engulf 1
    # Rules (Long)
    # 1.       Bar > 1.25*ATR
    # 2.       Body > 0.7*ATR
    # 3.       T = White Bar
    # 4.       T Body > T-1 Body
    # 5.       T Low < T-1 Low
    # 6.       T High > T-1 High
    @staticmethod
    def Engulf1Long(df, bar2atr, body2atr):
        if(set(['BarToATR', 'BodyToATR', 'Body', 'Low', 'High',
            'Open', 'Close']).issubset(df.columns)):
            logic1 = np.array(df.BarToATR) > bar2atr
            logic2 = np.array(df.BodyToATR) > body2atr
            logic3 = np.array(df.Close) > np.array(df.Open) # white bar
            logic4 = np.array(df.Body) > CandleUtility.GetArrayT(df.Body.tolist(), -1)
            logic5 = np.array(df.Low) < CandleUtility.GetArrayT(df.Low.tolist(), -1)
            logic6 = np.array(df.High) > CandleUtility.GetArrayT(df.High.tolist(), -1)

            return logic1 & logic2 & logic3 & logic4 & logic5 & logic6
        else:
            raise Exception('CandleShape: Invalid dataframe!')

    # Engulf1
    # Rules (Short)
    # 1.       Bar > 1.25*ATR
    # 2.       Body > 0.7*ATR
    # 3.       T = Filled Bar
    # 4.       T Body > T-1 Body
    # 5.       T Low < T-1 Low
    # 6.       T High > T-1 High
    @staticmethod
    def Engulf1Short(df, bar2atr, body2atr):
        if(set(['BarToATR', 'BodyToATR', 'Body', 'Low', 'High',
            'Open', 'Close']).issubset(df.columns)):
            logic1 = np.array(df.BarToATR) > bar2atr
            logic2 = np.array(df.BodyToATR) > body2atr
            logic3 = np.array(df.Close) < np.array(df.Open) # filled bar
            logic4 = np.array(df.Body) > CandleUtility.GetArrayT(df.Body.tolist(), -1)
            logic5 = np.array(df.Low) < CandleUtility.GetArrayT(df.Low.tolist(), -1)
            logic6 = np.array(df.High) > CandleUtility.GetArrayT(df.High.tolist(), -1)

            return logic1 & logic2 & logic3 & logic4 & logic5 & logic6
        else:
            raise Exception('CandleShape: Invalid dataframe!')

    # Engulf 2
    # Rules (Long)
    # 1.       Bar > 1.25*ATR
    # 2.       Body > 0.7*ATR
    # 3.       T = White Bar
    # 4.       T Body > T-1 Body
    # 5.       T Close > T-1 Close
    # 6.       T Close > T-2 Close
    # 7.       T High > T-1 High
    # 8.       T High > T-2 High
    @staticmethod
    def Engulf2Long(df, bar2atr, body2atr):
        if(set(['BarToATR', 'BodyToATR', 'Body', 'Low', 'High',
            'Open', 'Close']).issubset(df.columns)):
            logic1 = np.array(df.BarToATR) > bar2atr
            logic2 = np.array(df.BodyToATR) > body2atr
            logic3 = np.array(df.Close) > np.array(df.Open) # white bar
            logic4 = np.array(df.Body) > CandleUtility.GetArrayT(df.Body.tolist(), -1)
            logic5 = np.array(df.Close) > CandleUtility.GetArrayT(df.Close.tolist(), -1)
            logic6 = np.array(df.Close) > CandleUtility.GetArrayT(df.Close.tolist(), -2)
            logic7 = np.array(df.High) > CandleUtility.GetArrayT(df.High.tolist(), -1)
            logic8 = np.array(df.High) > CandleUtility.GetArrayT(df.High.tolist(), -2)

            return logic1 & logic2 & logic3 & logic4 & logic5 & logic6 & logic7 & logic8
        else:
            raise Exception('CandleShape: Invalid dataframe!')

    # Engulf2
    # Rules (Short)
    # 1.       Bar > 1.25*ATR
    # 2.       Body > 0.7*ATR
    # 3.       T = Filled Bar
    # 4.       T Body > T-1 Body
    # 5.       T Close < T-1 Close
    # 6.       T Close < T-2 Close
    # 7.       T Low < T-1 Low
    # 8.       T Low < T-2 Low
    @staticmethod
    def Engulf2Short(df, bar2atr, body2atr):
        if(set(['BarToATR', 'BodyToATR', 'Body', 'Low', 'High',
            'Open', 'Close']).issubset(df.columns)):
            logic1 = np.array(df.BarToATR) > bar2atr
            logic2 = np.array(df.BodyToATR) > body2atr
            logic3 = np.array(df.Close) < np.array(df.Open) # filled bar
            logic4 = np.array(df.Body) > CandleUtility.GetArrayT(df.Body.tolist(), -1)
            logic5 = np.array(df.Close) < CandleUtility.GetArrayT(df.Close.tolist(), -1)
            logic6 = np.array(df.Close) < CandleUtility.GetArrayT(df.Close.tolist(), -2)
            logic7 = np.array(df.Low) < CandleUtility.GetArrayT(df.Low.tolist(), -1)
            logic8 = np.array(df.Low) < CandleUtility.GetArrayT(df.Low.tolist(), -2)

            return logic1 & logic2 & logic3 & logic4 & logic5 & logic6 & logic7 & logic8
        else:
            raise Exception('CandleShape: Invalid dataframe!')

    # Inside Bar 1
    # Rules (Long)
    # 1.       T-2 Bar > 0.8*ATR
    # 2.       T-2 = Filled Bar
    # 3.       T Close > T-2 Open
    # 4.       T High > T-2 High
    # 5.       T-1 Low >= T-2 Low
    # 6.       T-1 High <= T-2 High
    # 7.       T-1 Close >= T-2 Close
    @staticmethod
    def InsideBar1Long(df, bart22atr):
        if(set(['Bar', 'ATR', 'Low', 'High', 'Open', 'Close']).issubset(df.columns)):
            logic1 = CandleUtility.GetArrayT(df.Bar.tolist(), -2) \
                > bart22atr * np.array(df.ATR)
            logic2 = CandleUtility.GetArrayT(df.Close.tolist(), -2) \
                < CandleUtility.GetArrayT(df.Open.tolist(), -2) # T-2 filled bar
            logic3 = np.array(df.Close) > CandleUtility.GetArrayT(df.Open.tolist(), -2)
            logic4 = np.array(df.High) > CandleUtility.GetArrayT(df.High.tolist(), -2)
            logic5 = CandleUtility.GetArrayT(df.Low.tolist(), -1) \
                >= CandleUtility.GetArrayT(df.Low.tolist(), -2)
            logic6 = CandleUtility.GetArrayT(df.High.tolist(), -1) \
                <= CandleUtility.GetArrayT(df.High.tolist(), -2)
            logic7 = CandleUtility.GetArrayT(df.Close.tolist(), -1) \
                >= CandleUtility.GetArrayT(df.Close.tolist(), -2)

            return logic1 & logic2 & logic3 & logic4 & logic5 & logic6 & logic7
        else:
            raise Exception('CandleShape: Invalid dataframe!')

    # Inside Bar 1
    # Rules (Short)
    # 1.       T-2 Bar > 0.8*ATR
    # 2.       T-2 = White Bar
    # 3.       T Close < T-2 Open
    # 4.       T Low < T-2 Low
    # 5.       T-1 Low >= T-2 Low
    # 6.       T-1 High <= T-2 High
    # 7.       T-1 Close >= T-2 Close
    @staticmethod
    def InsideBar1Short(df, bart22atr):
        if(set(['Bar', 'ATR', 'Low', 'High', 'Open', 'Close']).issubset(df.columns)):
            logic1 = CandleUtility.GetArrayT(df.Bar.tolist(), -2) \
                > bart22atr * np.array(df.ATR)
            logic2 = CandleUtility.GetArrayT(df.Close.tolist(), -2) \
                > CandleUtility.GetArrayT(df.Open.tolist(), -2) # T-2 white bar
            logic3 = np.array(df.Close) < CandleUtility.GetArrayT(df.Open.tolist(), -2)
            logic4 = np.array(df.Low) > CandleUtility.GetArrayT(df.Low.tolist(), -2)
            logic5 = CandleUtility.GetArrayT(df.Low.tolist(), -1) \
                >= CandleUtility.GetArrayT(df.Low.tolist(), -2)
            logic6 = CandleUtility.GetArrayT(df.High.tolist(), -1) \
                <= CandleUtility.GetArrayT(df.High.tolist(), -2)
            logic7 = CandleUtility.GetArrayT(df.Close.tolist(), -1) \
                >= CandleUtility.GetArrayT(df.Close.tolist(), -2)

            return logic1 & logic2 & logic3 & logic4 & logic5 & logic6 & logic7
        else:
            raise Exception('CandleShape: Invalid dataframe!')

    # Inside bar 2
    # Rules (Long)
    # 1.       T-2  Bar > 0.8*ATR
    # 2.       T-2 = Filled Bar
    # 3.       T Close > T-2 Open
    # 4.       T High > T-2 High
    # 5.       T-1 High <= T-2 High
    # 6.       T-1 Close >= T-2 Close
    # 7.       T-1 Bar < 0.8*ATR
    # 8.       T-1 Body < 0.7*Bar
    @staticmethod
    def InsideBar2Long(df, bart22atr, bart12atr, bodyt12atr):
        if(set(['Bar', 'ATR', 'Body', 'Low', 'High', 'Open', 'Close']).issubset(df.columns)):
            logic1 = CandleUtility.GetArrayT(df.Bar.tolist(), -2) \
                > bart22atr * np.array(df.ATR)
            logic2 = CandleUtility.GetArrayT(df.Close.tolist(), -2) \
                < CandleUtility.GetArrayT(df.Open.tolist(), -2) # T-2 filled bar
            logic3 = np.array(df.Close) > CandleUtility.GetArrayT(df.Open.tolist(), -2)
            logic4 = np.array(df.High) > CandleUtility.GetArrayT(df.High.tolist(), -2)
            logic5 = CandleUtility.GetArrayT(df.High.tolist(), -1) \
                <= CandleUtility.GetArrayT(df.High.tolist(), -2)
            logic6 = CandleUtility.GetArrayT(df.Close.tolist(), -1) \
                >= CandleUtility.GetArrayT(df.Close.tolist(), -2)
            logic7 = CandleUtility.GetArrayT(df.Bar.tolist(), -1) \
                < bart12atr * np.array(df.ATR)
            logic8 = CandleUtility.GetArrayT(df.Body.tolist(), -1) \
                < bodyt12atr * np.array(df.Bar)

            return logic1 & logic2 & logic3 & logic4 & logic5 & logic6 & logic7 & logic8
        else:
            raise Exception('CandleShape: Invalid dataframe!')

    # Inside Bar 2
    # Rules (Short)
    # 1.       T-2  Bar > 0.8*ATR
    # 2.       T-2 = White Bar
    # 3.       T Close < T-2 Open
    # 4.       T Low < T-2 Low
    # 5.       T-1 High <= T-2 High
    # 6.       T-1 Close >= T-2 Close
    # 7.       T-1 Bar < 0.8*ATR
    # 8.       T-1 Body < 0.7*Bar
    @staticmethod
    def  InsideBar2Short(df, bart22atr, bart12atr, bodyt12atr):
        if(set(['Bar', 'ATR', 'Body', 'Low', 'High', 'Open', 'Close']).issubset(df.columns)):
            logic1 = CandleUtility.GetArrayT(df.Bar.tolist(), -2) \
                > bart22atr * np.array(df.ATR)
            logic2 = CandleUtility.GetArrayT(df.Close.tolist(), -2) \
                > CandleUtility.GetArrayT(df.Open.tolist(), -2) # T-2 white bar
            logic3 = np.array(df.Close) < CandleUtility.GetArrayT(df.Open.tolist(), -2)
            logic4 = np.array(df.Low) < CandleUtility.GetArrayT(df.Low.tolist(), -2)
            logic5 = CandleUtility.GetArrayT(df.High.tolist(), -1) \
                <= CandleUtility.GetArrayT(df.High.tolist(), -2)
            logic6 = CandleUtility.GetArrayT(df.Close.tolist(), -1) \
                >= CandleUtility.GetArrayT(df.Close.tolist(), -2)
            logic7 = CandleUtility.GetArrayT(df.Bar.tolist(), -1) \
                < bart12atr * np.array(df.ATR)
            logic8 = CandleUtility.GetArrayT(df.Body.tolist(), -1) \
                < bodyt12atr * np.array(df.Bar)

            return logic1 & logic2 & logic3 & logic4 & logic5 & logic6 & logic7 & logic8
        else:
            raise Exception('CandleShape: Invalid dataframe!')

        