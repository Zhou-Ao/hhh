# -*- coding: utf-8 -*-
"""
Created on Tue Jan 31 13:47:11 2017

@author: strategy.intern.2
"""
import datetime
import pandas as pd
import numpy as np
import tia.bbg.datamgr as dm
from utility.utility import CandleUtility

class CandleBacktester:
    
    def __init__(self, ticker, startTime, endTime):
        self.ticker = ticker
        self.startTime = startTime
        self.endTime = endTime
        
        # retrieve data from blp
        self._mgr = dm.BbgDataManager()
        self._symbol = self._mgr[ticker]
        self._blp_df = self._symbol.get_historical(['PX_LAST'], startTime.strftime('%m/%d/%Y'), endTime.strftime('%m/%d/%Y'))
    
    def BacktestDaily(self, signalList, chartDf, signalParaDict, holdingPeriod):
        # check signal column in signalDf
        if not (set(signalList).issubset(chartDf.columns)):
            raise Exception('CandleBacktester: Invalid dataframe!')
        
        # check backtest period
        signalDf = chartDf.sort_index()
#        if startTime < signalDf.index[0].to_datetime() or endTime > signalDf.index[-1].to_datetime():
#            raise Exception('CandleBacktester: Backtesting period out of range!')
            
        signalDf = signalDf.loc[self.startTime:self.endTime, signalList]
        
        # create backtest dataframe
        backtest_df = pd.DataFrame(self._blp_df.iloc[:,0].tolist(), columns=['Last'], index = self._blp_df.index)
        backtest_df['LastAfter'] = CandleUtility.GetArrayT(backtest_df.Last.tolist(), holdingPeriod)
        backtest_df['Return'] = backtest_df.LastAfter / backtest_df.Last - 1
        backtest_df = pd.concat([backtest_df, signalDf[signalList]], axis=1)
        
        strategy_df = pd.DataFrame(np.array(backtest_df.Return).reshape(len(backtest_df.Return), 1) * np.array(backtest_df[signalList]),
                                   columns = [signal + 'Return' for signal in signalList],
                                    index = backtest_df.index)
        
        backtest_df = pd.concat([backtest_df, strategy_df], axis=1)
        backtest_df = backtest_df.dropna(how='any')
        
        
        with open('backtest' + datetime.datetime.now().strftime('%Y%m%d%H%M%S') + '.txt', 'w') as f:
            f.write('Backtest Summary\n')
            for signal in signalList:
                f.write(self.ticker + ' from ' + self.startTime.strftime('%Y-%m-%d') + ' to ' + self.endTime.strftime('%Y-%m-%d') + '\n')
                f.write('Holding Period: ' + str(holdingPeriod) + '\n')
                f.write('Signal: ' + signal + '\n')
                f.write('Parameter: ' + str(signalParaDict[signal]) + '\n')
                f.write('Total Hits: ' + str(len(backtest_df[backtest_df[signal] != 0])) + '\n')
                f.write('Total Wins: ' + str(len(backtest_df[backtest_df[signal + 'Return']> 0])) + '\n')
                if len(backtest_df[backtest_df[signal] != 0]) == 0:
                    f.write('Hit Rate: 0.0\n')
                else:
                    f.write('Hit Rate: ' + str(1.0*len(backtest_df[backtest_df[signal + 'Return']> 0]) / len(backtest_df[backtest_df[signal] != 0])) + '\n')
                f.write('Cum Return: ' + str(np.prod(1 + backtest_df[signal + 'Return']) - 1) + '\n')
                f.write('Max Return: ' + str(np.max(backtest_df[signal + 'Return'])) + '\n')
                f.write('Average Drawdown:' + str(np.mean(backtest_df[signal + 'Return'][backtest_df[signal + 'Return']< 0])) + '\n')
                f.write('Max Drawdown: ' + str(np.min(backtest_df[signal + 'Return'])) + '\n')
                f.write('\n')
        return backtest_df
        
#if __name__ == '__main__':
##    backtester = CandleBacktester('AUDNZD BGN Curncy', datetime.date(2009,9,10), datetime.date(2017,1,31))
##    backtester.BacktestDaily('Hammer2.0', chart.chartDf, 3)
#    pass