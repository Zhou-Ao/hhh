#load text mining library
library(tm)
library(topicmodels)
library(SnowballC)

#set working directory (modify path as needed)
myWd <- "U:\\Fed Speech\\R Code"
setwd("U:\\Fed Speech\\R Code")

names <- c("Yellen", "Brainard", "Lacker", "Dudley", "Fischer", "Powell", "Tarullo")
#names <- c("Yellen", "Brainard", "Lacker")

getSpeechFilenames <- function(nameList)
{
  filenames<-c()
  
  for (name in nameList)
  {
    filesDir <- paste(getwd(), "speech", name, sep = "/")
    filenames_temp <- list.files(filesDir, pattern=".txt")
    filenames_temp <- paste(filesDir, filenames_temp, sep = "/")
    
    filenames <- c(filenames, filenames_temp)
  }
  
  return(filenames)
}


filesDir <- paste(getwd(), "speech", "comp", sep = "/")
filenames <- getSpeechFilenames(names)


#read files into a character vector
myReadLines <- function(filename, encoding = "UTF-8")
{
  readLines(filename, encoding = "UTF-8")
}

files <- lapply(filenames, myReadLines)

#create corpus from vector
docs <- Corpus(VectorSource(files))

#inspect a particular document in corpus
writeLines(as.character(docs[[30]]))


#start preprocessing

#remove potentially problematic symbols
toSpace <- content_transformer(function(x, pattern) { return (gsub(pattern, " ", x))})

docs <- tm_map(docs, toSpace, "‑")
docs <- tm_map(docs, toSpace, "—")
docs <- tm_map(docs, toSpace, "’")
docs <- tm_map(docs, toSpace, "‘")
docs <- tm_map(docs, toSpace, "•")
docs <- tm_map(docs, toSpace, "”")
docs <- tm_map(docs, toSpace, "“")

#Transform to lower case
docs <-tm_map(docs,content_transformer(tolower))

#remove punctuation
docs <- tm_map(docs, removePunctuation)
#Strip digits
docs <- tm_map(docs, removeNumbers)
#remove stopwords
docs <- tm_map(docs, removeWords, stopwords("english"))
myStopwords <- c("a", "about", "above", "across", "after", "again", "against", "all", "almost", 
                 "alone", "along", "already", "also", "although", "always", "am", "among", "an", "and", "another", 
                 "any", "anybody", "anyone", "anything", "anywhere", "are", "area", "areas", "aren\'t", "around", 
                 "as", "ask", "asked", "asking", "asks", "at", "away", "b", "back", "backed", "backing", "backs", 
                 "be", "became", "because", "become", "becomes", "been", "before", "began", "behind", "being", 
                 "beings", "below", "best", "better", "between", "big", "both", "but", "by", "c", "came", "can", 
                 "cannot", "can\'t", "case", "cases", "certain", "certainly", "clear", "clearly", "come", "could", 
                 "couldn\'t", "d", "did", "didn\'t", "differ", "different", "differently", "do", "does", "doesn\'t", 
                 "doing", "done", "don\'t", "down", "downed", "downing", "downs", "during", "e", "each", "early", 
                 "either", "end", "ended", "ending", "ends", "enough", "even", "evenly", "ever", "every", "everybody", 
                 "everyone", "everything", "everywhere", "f", "face", "faces", "fact", "facts", "far", "felt", "few", 
                 "find", "finds", "first", "for", "four", "from", "full", "fully", "further", "furthered", "furthering", 
                 "furthers", "g", "gave", "general", "generally", "get", "gets", "give", "given", "gives", "go", "going", 
                 "good", "goods", "got", "great", "greater", "greatest", "group", "grouped", "grouping", "groups", "h", 
                 "had", "hadn\'t", "has", "hasn\'t", "have", "haven\'t", "having", "he", "he\'d", "he\'ll", "her", "here", 
                 "here\'s", "hers", "herself", "he\'s", "high", "higher", "highest", "him", "himself", "his", "how", 
                 "however", "how\'s", "i", "i\'d", "if", "i\'ll", "i\'m", "important", "in", "interest", "interested", 
                 "interesting", "interests", "into", "is", "isn\'t", "it", "its", "it\'s", "itself", "i\'ve", "j", "just", 
                 "k", "keep", "keeps", "kind", "knew", "know", "known", "knows", "l", "large", "largely", "last", "later", 
                 "latest", "least", "less", "let", "lets", "let\'s", "like", "likely", "long", "longer", "longest", "m", 
                 "made", "make", "making", "man", "many", "may", "me", "member", "members", "men", "might", "more", "most", 
                 "mostly", "mr", "mrs", "much", "must", "mustn\'t", "my", "myself", "n", "necessary", "need", "needed", 
                 "needing", "needs", "never", "new", "newer", "newest", "next", "no", "nobody", "non", "noone", "nor", "not", 
                 "nothing", "now", "nowhere", "number", "numbers", "o", "of", "off", "often", "old", "older", "oldest", "on", 
                 "once", "one", "only", "open", "opened", "opening", "opens", "or", "order", "ordered", "ordering", "orders", 
                 "other", "others", "ought", "our", "ours", "ourselves", "out", "over", "own", "p", "part", "parted", "parting", 
                 "parts", "per", "perhaps", "place", "places", "point", "pointed", "pointing", "points", "possible", "present", 
                 "presented", "presenting", "presents", "problem", "problems", "put", "puts", "q", "quite", "r", "rather", 
                 "really", "right", "room", "rooms", "s", "said", "same", "saw", "say", "says", "second", "seconds", "see", 
                 "seem", "seemed", "seeming", "seems", "sees", "several", "shall", "shan\'t", "she", "she\'d", "she\'ll", "she\'s", 
                 "should", "shouldn\'t", "show", "showed", "showing", "shows", "side", "sides", "since", "small", "smaller", 
                 "smallest", "so", "some", "somebody", "someone", "something", "somewhere", "state", "states", "still", "such", 
                 "sure", "t", "take", "taken", "than", "that", "that\'s", "the", "their", "theirs", "them", "themselves", "then", 
                 "there", "therefore", "there\'s", "these", "they", "they\'d", "they\'ll", "they\'re", "they\'ve", "thing", "things", 
                 "think", "thinks", "this", "those", "though", "thought", "thoughts", "three", "through", "thus", "to", "today", 
                 "together", "too", "took", "toward", "turn", "turned", "turning", "turns", "two", "u", "under", "until", "up", 
                 "upon", "us", "use", "used", "uses", "v", "very", "w", "want", "wanted", "wanting", "wants", "was", "wasn\'t", 
                 "way", "ways", "we", "we\'d", "well", "we\'ll", "wells", "went", "were", "we\'re", "weren\'t", "we\'ve", "what", 
                 "what\'s", "when", "when\'s", "where", "where\'s", "whether", "which", "while", "who", "whole", "whom", "who\'s", 
                 "whose", "why", "why\'s", "will", "with", "within", "without", "won\'t", "work", "worked", "working", "works", 
                 "would", "wouldn\'t", "x", "y", "year", "years", "yes", "yet", "you", "you\'d", "you\'ll", "young", "younger", 
                 "youngest", "your", "you\'re", "yours", "yourself", "yourselves", "you\'ve", "z")
docs <- tm_map(docs, removeWords, myStopwords)
#remove whitespace
docs <- tm_map(docs, stripWhitespace)
#Good practice to check every now and then
writeLines(as.character(docs[[30]]))
#Stem document
docs <- tm_map(docs,stemDocument)


#Create document-term matrix
dtm <- DocumentTermMatrix(docs)
#convert rownames to filenames
rownames(dtm) <- filenames
#collapse matrix by summing over columns
freq <- colSums(as.matrix(dtm))
#length should be total number of terms
length(freq)
#create sort order (descending)
ord <- order(freq,decreasing=TRUE)
#List all terms in decreasing order of freq and write to disk
freq[ord]
write.csv(freq[ord], paste(filesDir, "word_freq.csv", sep = "/"))


#Set parameters for Gibbs sampling
burnin <- 4000
iter <- 2000
thin <- 500
seed <-list(2003,5,63,100001,765)
nstart <- 5
best <- TRUE

#Number of topics
k <- 8

#Run LDA using Gibbs sampling
ldaOut <- LDA(dtm,k, method="Gibbs", control=list(nstart=nstart, seed = seed, best=best, burnin = burnin, iter = iter, thin=thin))


#write out results
#docs to topics
ldaOut.topics <- as.matrix(topics(ldaOut))
write.csv(ldaOut.topics, file=paste(filesDir, paste("LDAGibbs",k,"DocsToTopics.csv"), sep = "/"))


#top 6 terms in each topic
ldaOut.terms <- as.matrix(terms(ldaOut, 10))
write.csv(ldaOut.terms,file=paste(filesDir, paste("LDAGibbs",k,"TopicsToTerms.csv"), sep = "/"))


#probabilities associated with each topic assignment
topicProbabilities <- as.data.frame(ldaOut@gamma)
write.csv(topicProbabilities,file=paste(filesDir, paste("LDAGibbs",k,"TopicProbabilities.csv"), sep = "/"))


#Find relative importance of top 2 topics
topic1ToTopic2 <- lapply(1:nrow(dtm),function(x)
  sort(topicProbabilities[x,])[k]/sort(topicProbabilities[x,])[k-1])


#Find relative importance of second and third most important topics
topic2ToTopic3 <- lapply(1:nrow(dtm),function(x)
  sort(topicProbabilities[x,])[k-1]/sort(topicProbabilities[x,])[k-2])

#write to file
write.csv(topic1ToTopic2,file=paste(filesDir, paste("LDAGibbs", k, "Topic1ToTopic2.csv"), sep = "/"))
write.csv(topic2ToTopic3,file=paste(filesDir, paste("LDAGibbs", k, "Topic2ToTopic3.csv"), sep = "/"))
