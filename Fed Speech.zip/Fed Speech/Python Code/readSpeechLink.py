# -*- coding: utf-8 -*-
"""
Created on Mon Jan 16 11:00:55 2017

@author: strategy.intern.2
"""

import requests
import re
from bs4 import BeautifulSoup

def read_fed_speech_link_by_year_and_name((year_list, name, folder)):
    with open(folder + '\\' + name + '.txt', 'w') as f:
        for year in year_list:
            url = 'https://www.federalreserve.gov/newsevents/speech/' + str(year) + 'speech.htm'
            base_url = '/'.join(url.split('/')[0:3])
            page = requests.get(url)
                
            soup = BeautifulSoup(page.content, 'html.parser')
            tag_speaker = soup.find_all('div', attrs={'class': 'speaker'})
            
            for tag in tag_speaker:
                if name in tag.string:
            #        print(tag)
                    tag_title = tag.previous_sibling.previous_sibling
                    f.write('Title: ' + tag_title.string + '\n')
                    f.write('Url: ' + base_url + tag_title.find('a').attrs['href'] + '\n')