# -*- coding: utf-8 -*-
"""
Created on Mon Jan 16 11:45:41 2017

@author: strategy.intern.2
"""
import requests
import re
from bs4 import BeautifulSoup

urlList = []

folder = '.\\speech'
name = 'Brainard'
with open(folder + '\\' + name + '.txt', 'r') as f:
    for line in f:
        if 'Url:' in line:
            urlList.append(line[5:-1])
            
#read_fomc_minutes_Html((urlList[0], folder + '\\' + Yellen))
#url = urlList[0]
#page = requests.get(url)
#date = ''.join(re.findall('[0-9]', url))
#    
#soup = BeautifulSoup(page.content, 'html.parser')
#
#p_set = soup.find_all('p')
#
#text = u''
#
#for p_elem in p_set:
#    for content in p_elem.contents:
#        if content.name != 'p' and content.string != None:
#            text += unicode(content.string)
#            text += u'\n'
#        
#
#with open(folder + '\\' +'fomcminutes' + date + '.txt', 'w') as f:
#    f.write(text.encode('utf-8'))

folder = [folder + '\\' + name for i in range(0, len(urlList))]
input_para = zip(urlList, folder)

map(read_fomc_html, input_para)