# -*- coding: utf-8 -*-
"""
Created on Tue Jan 24 16:17:17 2017

@author: strategy.intern.2
"""

import datetime
import numpy as np
import pandas as pd

class CandleChart:
    '''
    Class of Candle Chart
    '''
    
    def __int__(self, ticker, datetimes, ):
        
        




class CandleBar:
    '''
    Class of Candle Bar
    '''
    
    def __int__(self, ticker, datetime, period, size, op, hp, lp, cp, pcp):
        self.ticker = ticker
        self.datetime = datetime
        self.period = self._validateBarPeriod(period)
        self.size = int(size)
        
        self.open = float(op)
        self.high = float(hp)
        self.low = float(lp)
        self.close = float(cp)
        self.preClose = float(pcp)
        
        self.body = self.close - self.open
        self.upperShadow = self.high - np.max([self.open, self.close])
        self.lowerShadow = np.min([self.open, self.close]) - self.low
        self.bar = self.high - self.open
        
        self.tr = np.max([self.high, self.preClose]) - np.min([self.low, self.preClose])
        
        
    def _validateBarPeriod(period):
        if(type(period) != str):
            return 'Unknown'
        elif(period.lower() == 'year'):
            return 'Year'
        elif(period.lower() == 'month'):
            return 'Month'
        elif(period.lower() == 'week'):
            return 'Week'
        elif(period.lower() == 'day'):
            return 'Day'
        elif(period.lower() == 'minute'):
            return 'Minute'
        else:
            return 'Unknown'