# -*- coding: utf-8 -*-
"""
Created on Tue Jan 24 16:17:17 2017

@author: strategy.intern.2
"""

import datetime
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.dates import date2num
import matplotlib.ticker as mticker
import matplotlib.dates as mdates
from matplotlib.finance import candlestick_ohlc
from shape import CandleShape

class CandleChart:
    '''
    Class of Candle Chart
    '''
    
    def __init__(self, ticker, period, size, datetimeList, openPriceList, 
                highPriceList, lowPriceList, closePriceList, 
                preClosePriceList = None):
        # chart particulars
        self.ticker = ticker
        self.period = self._validateBarPeriod(period)
        self.size = size
        
        # sort list, time ascending        
        if datetimeList[0] > datetimeList[-1]:
            datetimeList.reverse()
            openPriceList.reverse()
            highPriceList.reverse()
            lowPriceList.reverse()
            closePriceList.reverse()
            if preClosePriceList is not None:
                preClosePriceList.reverse()
        
        # initialize signal dataframe
        self.signalDf = pd.DataFrame(index = datetimeList)
        self.signNum = {'Engulf' : 
                            {1 : 0,
                             2 : 0},
                        'Hammer' : 
                            {1 : 0,
                             2 : 0,
                             3 : 0},
                        'InsideBar' : 
                            {1 : 0,
                             2 : 0}}
        
        # validate list size and generate dataframe
        if preClosePriceList is None:
            if(len(datetimeList) == len(openPriceList) == len(highPriceList)
                == len(lowPriceList) == len(closePriceList)):        
                self.chartDf = pd.DataFrame({
                        'Open'     : openPriceList,
                        'High'     : highPriceList,
                        'Low'      : lowPriceList,
                        'Close'    : closePriceList,
                        'PreClose' : [np.nan] + closePriceList[:-1]
                        },
                        index = datetimeList, 
                        columns = ['Open', 'High', 'Low', 'Close', 'PreClose'])
                
                self.chartDf = self.chartDf.sort_index()
            else:
                raise Exception('Unmatched list size!')
        else:
            if(len(datetimeList) == len(openPriceList) 
                == len(highPriceList)
                == len(lowPriceList) 
                == len(closePriceList) 
                == len(preClosePriceList)):        
                self.chartDf = pd.DataFrame({
                        'Open'     : openPriceList,
                        'High'     : highPriceList,
                        'Low'      : lowPriceList,
                        'Close'    : closePriceList,
                        'PreClose' : preClosePriceList
                        },
                        index = datetimeList, 
                        columns = ['Open', 'High', 'Low', 'Close', 'PreClose'])
                
                self.chartDf = self.chartDf.sort_index()
            else:
                raise Exception('Unmatched list size!')
            
    def CaculateBarMetrics(self):
        self.chartDf = self.chartDf.sort_index()
        
        # body = close - open
        self.chartDf['Body'] = self.chartDf.Close - self.chartDf.Open
        # upper shadow = high - max(open, close)
        self.chartDf['UpperShadow'] = self.chartDf.apply(lambda row:
            row.High - np.max([row.Open, row.Close]), axis = 1)
        # lower shadow = min(open, close) - low
        self.chartDf['LowerShadow'] = self.chartDf.apply(lambda row:
            np.min([row.Open, row.Close]) - row.Low, axis = 1)
        # bar = high - low
        self.chartDf['Bar'] = self.chartDf.High - self.chartDf.Low
        
        # ratios
        self.chartDf['UpperShadowToBody'] \
            = self.chartDf.UpperShadow / np.abs(self.chartDf.Body)
        self.chartDf['LowerShadowToBody'] \
            = self.chartDf.LowerShadow / np.abs(self.chartDf.Body)
        self.chartDf['UpperShadowToBar'] \
            = self.chartDf.UpperShadow / self.chartDf.Bar
        self.chartDf['LowerShadowToBar'] \
            = self.chartDf.LowerShadow / self.chartDf.Bar
        self.chartDf['UpperShadowToLowerShadow'] \
            = self.chartDf.UpperShadow / self.chartDf.LowerShadow
        self.chartDf['LowerShadowToUpperShadow'] \
            = self.chartDf.LowerShadow / self.chartDf.UpperShadow
    
    def CaculateATR(self, window = 5, method = 'arithmetic'):
        self.chartDf = self.chartDf.sort_index()
        
        # TR and ATR
        self.chartDf['TR'] = self.chartDf.apply(lambda row:
            np.max([row.High, row.PreClose]) - np.min([row.Low, row.PreClose]),
                  axis = 1)
        if method == 'arithmetic':
            self.chartDf['ATR'] \
                = self.chartDf.TR.rolling(window = window).mean()            
        elif method == 'exponential':
            self.chartDf['eATR'] \
                = self.chartDf.TR.ewm(window = window).mean()
        else:
            raise Exception('Unknown method! Only support arithmetic/exponential!')
            
        self.chartDf['BarToATR'] = self.chartDf.Bar / self.chartDf.ATR
        self.chartDf['BodyToATR'] = self.chartDf.Body / self.chartDf.ATR
        
        self.chartDf['UpperShadowToATR'] = self.chartDf.UpperShadow / self.chartDf.ATR
        self.chartDf['LowerShadowToATR'] = self.chartDf.LowerShadow / self.chartDf.ATR
                    
    def PlotChart(self):
        self.chartDf = self.chartDf.sort_index()
        
        fig = plt.figure()
        ax = plt.subplot2grid((1,1), (0,0))
        
        candlestick_ohlc(ax, zip(map(date2num, self.chartDf.index), self.chartDf.Open.tolist(),
            self.chartDf.High.tolist(), self.chartDf.Low.tolist(), self.chartDf.Close.tolist()))
        
        for label in ax.xaxis.get_ticklabels():
            label.set_rotation(45)

        ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m-%d'))
        ax.xaxis.set_major_locator(mticker.MaxNLocator(10))
        ax.grid(True)
        
        plt.xlabel('Date')
        plt.ylabel(self.ticker)
        plt.title(self.ticker + ' ' + str(self.size) + ' ' + self.period + ' Bar')
        plt.legend()
        plt.subplots_adjust(left=0.09, bottom=0.20, right=0.94, top=0.90, wspace=0.2, hspace=0)
        plt.show()
        
    def AddEngulf1(self, bar2atr, body2atr):
        self.chartDf = self.chartDf.sort_index()
        
        num = self.signNum['Engulf'][1]
        self.signalDf['Engulf1.' + str(num) +'Long'] = CandleShape.Engulf1Long(self.chartDf, bar2atr, body2atr)
        self.signalDf['Engulf1.' + str(num) +'Long'] = CandleShape.Engulf1Short(self.chartDf, bar2atr, body2atr)
        
        self.signNum['Engulf'][1] += 1
            
                    
                    
    def _validateBarPeriod(self, period):
        if(type(period) != str):
            return 'Unknown'
        elif(period.lower() == 'year'):
            return 'Year'
        elif(period.lower() == 'month'):
            return 'Month'
        elif(period.lower() == 'week'):
            return 'Week'
        elif(period.lower() == 'day'):
            return 'Day'
        elif(period.lower() == 'minute'):
            return 'Minute'
        else:
            return 'Unknown'