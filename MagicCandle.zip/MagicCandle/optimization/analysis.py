# -*- coding: utf-8 -*-
"""
Created on Mon Feb 06 09:55:37 2017

@author: strategy.intern.2
"""
import pandas as pd
import os
import datetime

#fileName = 'backtest.txt'

fileNames = []

# folder = 'backtest20170207'
folder = 'backtest_hammer'

# for fileName in os.listdir(os.path.join(os.getcwd(), folder)):
#    if fileName.endswith('.txt'):
#        fileNames.append(os.path.join(os.getcwd(), folder, fileName))
        

# for fileName in os.listdir(os.getcwd()):
#     if fileName.endswith('.txt'):
#         fileNames.append(os.path.join(os.getcwd(), fileName))

for fileName in os.listdir(os.path.join('C:/Python', folder)):
   if fileName.endswith('.txt'):
       fileNames.append(os.path.join('C:/Python', folder, fileName))


result_df = pd.DataFrame(columns = ['Curncy', 'Signal', 'Parameters', 'HoldingPeriod', 'Period', 
                                    'TotalHits', 'TotalWins', 'HitRate', 'CumReturn',
                                    'MaxReturn', 'AveDrawdown', 'MaxDrawdown'])
for fileName in fileNames:
    print(fileName)
    with open(fileName, 'r') as f:
        for line in f.readlines():
            if 'Curncy' in line:
                curncy = line[:6]
                period = line[-25:-1]
            elif 'Holding Period:' in line:
                holdingPeriod  = int(line[16:-1])
            elif 'Signal:' in line:
                signal = line[8:-1]
            elif 'Parameter:' in line:
                para = line[11:-1]
            elif 'Total Hits:' in line:
                hits = int(line[12:-1])
            elif 'Total Wins:' in line:
                wins = int(line[12:-1])
            elif 'Hit Rate: 0.0Cum Return: 0.0' in line:
                hitRate = 0.0
                cumReturn = 0.0
            elif 'Hit Rate:' in line:
                hitRate = float(line[10:-1])
            elif 'Cum Return:' in line:
                cumReturn = float(line[12:-1])
            elif 'Max Return:' in line:
                maxReturn = float(line[12:-1])
            elif 'Average Drawdown:' in line:
                aveDrawdown = float(line[17:])
            elif 'Max Drawdown:' in line:
                maxDrawdown = float(line[14:])
            elif line == '\n':
                temp_df = pd.DataFrame({
                                        'Curncy' : curncy,
                                        'Signal' : signal,
                                        'Parameters' : para,
                                        'HoldingPeriod' : holdingPeriod,
                                        'Period' : period,
                                        'TotalHits' : hits,
                                        'TotalWins' : wins,
                                        'HitRate' : hitRate,
                                        'CumReturn' : cumReturn,
                                        'MaxReturn' : maxReturn,
                                        'AveDrawdown' : aveDrawdown,
                                        'MaxDrawdown' : maxDrawdown},
                                        index = [0])
                
                result_df = result_df.append(temp_df, ignore_index=True)
                
                
#copy_df = result_df.copy()
#curncySet = set(copy_df.Curncy)
#signalSet = set(copy_df.Signal)
#out_df = pd.DataFrame(columns = ['Curncy', 'Signal', 'Parameters', 'HoldingPeriod', 'Period', 
#                                    'TotalHits', 'TotalWins', 'HitRate', 'CumReturn',
#                                    'MaxReturn', 'AveDrawdown', 'MaxDrawdown'])

#for curncy in curncySet:
#    for signal in signalSet:
#        print(curncy + ": " + signal)
#        #curncy = 'USDJPY'
#        #signal = 'InsideBar2.78'
#        curncy_df = copy_df[copy_df.Curncy == curncy]
#        curncy_df = curncy_df[curncy_df.Signal == signal]
#        curncy_df = curncy_df[curncy_df.HitRate > 0.5]
#        curncy_df = curncy_df[curncy_df.TotalHits > 20]
#        curncy_df = curncy_df[curncy_df.CumReturn > 0]
#
#        if len(curncy_df) == 8:
#            out_df = out_df.append(curncy_df, ignore_index=True)
            
            
#holdingPeriod == 3
copy_df = result_df[result_df.HoldingPeriod == 3].copy()
curncySet = set(copy_df.Curncy)
signalSet = set(copy_df.Signal)
out_df = pd.DataFrame(columns = ['Curncy', 'Signal', 'Parameters', 'HoldingPeriod', 'Period', 
                                    'TotalHits', 'TotalWins', 'HitRate', 'CumReturn',
                                    'MaxReturn', 'AveDrawdown', 'MaxDrawdown'])

#for curncy in curncySet:
#    for signal in signalSet:
#        print(curncy + ": " + signal)
#        #curncy = 'USDJPY'
#        #signal = 'InsideBar2.78'
#        curncy_df = copy_df[copy_df.Curncy == curncy]
#        curncy_df = curncy_df[curncy_df.Signal == signal]
#        
#        if (curncy_df[curncy_df.Period == '2009-09-16 to 2017-02-06'].HitRate.tolist()[0] > 0.5
#            and curncy_df[curncy_df.Period == '2009-09-16 to 2017-02-06'].CumReturn.tolist()[0] > 0
#            and ((curncy_df[curncy_df.Period == '2013-01-01 to 2015-12-31'].HitRate.tolist()[0] > 0.5
#                and curncy_df[curncy_df.Period == '2013-01-01 to 2015-12-31'].CumReturn.tolist()[0] > 0)
#                or
#                (curncy_df[curncy_df.Period == '2016-01-01 to 2017-02-06'].HitRate.tolist()[0] > 0.5
#                and curncy_df[curncy_df.Period == '2016-01-01 to 2017-02-06'].CumReturn.tolist()[0] > 0))):
#                out_df = out_df.append(curncy_df, ignore_index=True)
                
periodDict = {'t_full' : '2009-09-16 to 2017-02-06',
              't_2' : '2009-09-16 to 2012-12-31',
              't_1' : '2013-01-01 to 2015-12-31',
              't' : '2016-01-01 to 2017-02-06'}
                
numOfDays = {'t_full' : (datetime.date(2017,2,6) - datetime.date(2009, 9, 16)).days,
             't_2' : (datetime.date(2012,12,31) - datetime.date(2009, 9, 16)).days,
             't_1' : (datetime.date(2015,12,31) - datetime.date(2013, 1, 1)).days,
             't' : (datetime.date(2017,2,6) - datetime.date(2016, 1, 1)).days}

                
                
for curncy in curncySet:
    for signal in signalSet:
        print(curncy + ": " + signal)
        curncy_df = copy_df[copy_df.Curncy == curncy]
        curncy_df = curncy_df[curncy_df.Signal == signal]

        logic1 = curncy_df[curncy_df.Period == periodDict['t']].HitRate.tolist()[0]>0.5 and curncy_df[curncy_df.Period == periodDict['t']].TotalHits.tolist()[0] / numOfDays['t'] > 20.0/365/3
        logic2 = curncy_df[curncy_df.Period == periodDict['t_1']].HitRate.tolist()[0]>0.5 and curncy_df[curncy_df.Period == periodDict['t_1']].TotalHits.tolist()[0] / numOfDays['t_1'] > 20.0/365/3
        logic3 = curncy_df[curncy_df.Period == periodDict['t_2']].HitRate.tolist()[0]>0.5 and curncy_df[curncy_df.Period == periodDict['t_2']].TotalHits.tolist()[0] / numOfDays['t_2'] > 20.0/365/3

        if logic1 or (logic2 and logic3):
            out_df = out_df.append(curncy_df, ignore_index=True)
            
for curncy in curncySet:
    for signal in ['Engulf1', 'Engulf2', 'InsideBar1', 'InsideBar2']:
        print(curncy + ":" + signal)
        temp_df = out_df[out_df.Curncy == curncy][[signal in sig for sig in out_df[out_df.Curncy == curncy].Signal]]
        
        if len(temp_df) > 0:
            temp_df.to_excel(os.path.join(os.getcwd(), signal, curncy+'.xlsx'))