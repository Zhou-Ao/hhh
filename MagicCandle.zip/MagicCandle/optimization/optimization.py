# -*- coding: utf-8 -*-
"""
Created on Tue Jan 31 16:36:06 2017

@author: strategy.intern.2
"""

import datetime
import pandas as pd
import numpy as np
import tia.bbg.datamgr as dm
from candle.candle import CandleChart
from backtesting.backtest import CandleBacktester

# read input data
ticker = 'AUDNZD BGN Curncy'
#startTime = datetime.date(2009,9,10)
#endTime = datetime.date(2017,1,31)
endTime = datetime.date.today()
startTime = endTime - datetime.timedelta(900*3)

mgr = dm.BbgDataManager()
curncy = mgr[ticker]

rawDf = curncy.get_historical(['PX_OPEN', 'PX_HIGH', 'PX_LOW', 'PX_LAST'], 
                              startTime.strftime('%m/%d/%Y'), endTime.strftime('%m/%d/%Y'))

chart = CandleChart(ticker, 'Day', 1, rawDf.index.tolist(), 
    rawDf.PX_OPEN.tolist(), rawDf.PX_HIGH.tolist(), rawDf.PX_LOW.tolist(), rawDf.PX_LAST.tolist())

# calculate candle metrics
chart.CaculateBarMetrics()
chart.CaculateATR()

paraList = []
for bar2atr in np.arange(0.6, 0.8, 0.02):
    for shadow2shadow in np.arange(0.2, 0.5, 0.02):
        for shadow2bar in np.arange(0.4, 0.7, 0.02):
            for shadowplusbody2atr in np.arange(bar2atr-0.1, bar2atr, 0.02):
                print((bar2atr, shadow2shadow, shadow2bar, shadowplusbody2atr))
                paraList.append((bar2atr, shadow2shadow, shadow2bar, shadowplusbody2atr))
                chart.AddHammer2(bar2atr, shadow2shadow, shadow2bar, shadowplusbody2atr)
                
                
signalList = [signal for signal in chart.chartDf.columns if 'Hammer2' in signal]                

# backtest
backtester = CandleBacktester(ticker, startTime, endTime)
holdingPeriod = 3
backtester.BacktestDaily(signalList, chart.chartDf, holdingPeriod)