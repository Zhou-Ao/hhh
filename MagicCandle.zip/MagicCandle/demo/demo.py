# -*- coding: utf-8 -*-
"""
Created on Wed Feb 01 09:18:37 2017

@author: strategy.intern.2
"""

import datetime
import pandas as pd
import tia.bbg.datamgr as dm
from candle.candle import CandleChart
from backtesting.backtest import CandleBacktester

# read input data
ticker = 'AUDNZD BGN Curncy'
#startTime = datetime.date(2009,9,10)
#endTime = datetime.date(2017,1,31)
endTime = datetime.date.today()
startTime = endTime - datetime.timedelta(900*3)


# retrive data from bloomblog
mgr = dm.BbgDataManager()
curncy = mgr[ticker]

rawDf = curncy.get_historical(['PX_OPEN', 'PX_HIGH', 'PX_LOW', 'PX_LAST'], 
                              startTime.strftime('%m/%d/%Y'), endTime.strftime('%m/%d/%Y'))

# read data from excel
#rawDf = pd.read_excel('input.xlsx')

# create candlestick
chart = CandleChart(ticker, 'Day', 1, rawDf.index.tolist(), 
    rawDf.PX_OPEN.tolist(), rawDf.PX_HIGH.tolist(), rawDf.PX_LOW.tolist(), rawDf.PX_LAST.tolist())

# plot candlestick chart, maybe need couple of seconds to render
chart.PlotChart()

# calculate candle metrics
chart.CaculateBarMetrics()
chart.CaculateATR()

# Add trading signals
chart.AddEngulf1(1.7, 0.7)
chart.AddEngulf1(1.25, 0.7)
chart.AddEngulf1(1.15, 0.6)

chart.AddHammer1(0.3, 0.42, 0.3, 2, 0.4)
chart.AddHammer2(0.8, 0.48, 0.6, 0.8)
chart.AddHammer3(0.6, 0.5, 0.1, 0.25, 0.7)

chart.AddInsideBar1(0.9)
chart.AddInsideBar2(0.8, 0.8, 0.7)

# create backtest engine
backtester = CandleBacktester(ticker, startTime, endTime)
holdingPeriod = 3
backtester.BacktestDaily(['Engulf1.0', 'Engulf1.1', 'Engulf1.2', 'Hammer1.0'], chart.chartDf, holdingPeriod)