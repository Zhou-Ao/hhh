# -*- coding: utf-8 -*-
"""
Created on Tue Jan 31 14:43:43 2017

@author: strategy.intern.2
"""
import numpy as np

class CandleUtility:
    
    @staticmethod
    def GetArrayT(inputList, T):
        if type(T) != int:
            raise Exception('Please insert a int for time length!')
        if T > 0:
            return np.array(inputList[T:] + [np.nan] * T)
        elif T < 0:
            return np.array([np.nan] * (-T) + inputList[:T])
        else:
            return np.array(inputList)